from .twitterSentiment import API, StructureStatusesData, SentimentScore

name = 'twitterSentiment'
__version__ = '0.2.1'